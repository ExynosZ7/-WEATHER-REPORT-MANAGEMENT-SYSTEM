package com.example.miniwttr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
